//
//  Trip+CoreDataClass.swift
//  Travel Buddy
//
//  Created by Admin on 2024-08-17.
//
//

import Foundation
import CoreData

@objc(Trip)
public class Trip: NSManagedObject {

}
