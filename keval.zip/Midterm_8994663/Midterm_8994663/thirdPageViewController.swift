//
//  thirdPageViewController.swift
//  Midterm_8994663
//
//  Created by Admin on 2024-07-06.
//

import UIKit

class thirdPageViewController: UIViewController {
    
    
    var tableTableViewController: tableTableViewController?
    
    @IBOutlet weak var dueDateSwitch: UISwitch!
    
    
    @IBOutlet weak var ascending: UIButton!
    
   
    @IBOutlet weak var descendingButton: UIButton!
    
    @IBOutlet weak var pendingCase: UIButton!
    
    @IBOutlet weak var completedcase: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Get a reference to the TasksTableViewController
                if let tableTableVC = self.tabBarController?.viewControllers?.compactMap({ $0 as? tableTableViewController }).first {
                    self.tableTableViewController = tableTableVC
                }
        
        
        
    }
    
    
    
    
    @IBAction func sortByDueDateSwitchChanged(_ sender: UISwitch) {
        if sender.isOn {
                    // Sort tasks by due date ascending
                    tableTableViewController?.tasks.sort { $0.dueDate < $1.dueDate }
                } else {
                    // Sort tasks by due date descending
                    tableTableViewController?.tasks.sort { $0.dueDate > $1.dueDate }
                }
                tableTableViewController?.tableView.reloadData()
        
    }
    
    @IBAction func ascendingButton(_ sender: UIButton) {
        // Sort tasks by status ascending (alphabetical order)
               tableTableViewController?.tasks.sort { $0.status < $1.status }
               tableTableViewController?.tableView.reloadData()
        
    }
    
    
    @IBAction func descendingButton(_ sender: UIButton) {
        // Sort tasks by status descending (reverse alphabetical order)
                tableTableViewController?.tasks.sort { $0.status > $1.status }
                tableTableViewController?.tableView.reloadData()
            }
    
    @IBAction func pendingButton(_ sender: UIButton) {
        // Filter tasks to show only pending tasks
               let filteredTasks = tableTableViewController?.tasks.filter { $0.status == "Pending" }
               tableTableViewController?.tasks = filteredTasks ?? []
               tableTableViewController?.tableView.reloadData()
        

    }
    
    @IBAction func completedButton(_ sender: UIButton) {
        // Filter tasks to show only completed tasks
                let filteredTasks = tableTableViewController?.tasks.filter { $0.status == "Completed" }
                tableTableViewController?.tasks = filteredTasks ?? []
                tableTableViewController?.tableView.reloadData()
        

    }
    
    // Function to pass reference of tableTableViewController
       override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
           if let tableTableVC = segue.destination as? tableTableViewController {
               self.tableTableViewController = tableTableVC
           }
       }
    
    
    

}
