//
//  secondPageViewController.swift
//  Midterm_8994663
//
//  Created by Admin on 2024-07-06.
//

import UIKit

class secondPageViewController: UIViewController {
    var task: Task?
    
    
    @IBOutlet weak var taskStatus: UITextField!
    
    
    @IBOutlet weak var titleField: UITextField!
    
    
    @IBOutlet weak var descriptionField: UITextField!
    
    
    @IBOutlet weak var dateChange: UIDatePicker!
    
    
    @IBOutlet weak var imageField: UIImageView!
    
    
    @IBOutlet weak var backButton: UIButton!
    
        
    @IBAction func backButtonTapped(_ sender: UIButton) {
        self.dismiss(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if let task = task {
            titleField.text = task.title
            descriptionField.text = task.description
            dateChange.date = task.dueDate
            
            if task.dueDate < Date() {
                           taskStatus.text = "Completed"
                       } else {
                           taskStatus.text = "Pending"
                       }
            if let imageName = task.imageName {
                print("Attempting to load image: \(imageName)")
                imageField.image = UIImage(named: imageName)
            } else {
                imageField.image = UIImage(named: "defaultImage")
            }
            // Setup back button action
                   backButton.addTarget(self, action: #selector(backButtonTapped(_:)), for: .touchUpInside)
            
            // Do any additional setup after loading the view.
        }
        func formatDate(_ date: Date) -> String {
            let formatter = DateFormatter()
            formatter.dateStyle = .medium
            formatter.timeStyle = .short
            return formatter.string(from: date)
        }
        
        
        
        
    }
}
