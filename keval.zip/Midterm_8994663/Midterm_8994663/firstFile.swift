//
//  firstFile.swift
//  Midterm_8994663
//
//  Created by Admin on 2024-07-07.
//

import Foundation
import UIKit
struct Task {
    var title: String
    var description: String
    var dueDate: Date
    var status: String
    var imageName: String?
    

    init(title: String, description: String, dueDate: Date, status: String, imageName: String? = nil) {
        self.title = title
        self.description = description
        self.dueDate = dueDate
        self.status = status
        self.imageName = imageName
    }
}
