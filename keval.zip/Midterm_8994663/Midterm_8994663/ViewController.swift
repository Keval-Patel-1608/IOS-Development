//
//  ViewController.swift
//  Midterm_8994663
//
//  Created by Admin on 2024-07-06.
//

import UIKit


class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    var tasks: [Task] = []
    var tableTableViewController: tableTableViewController?
    var imageNames = ["canteen", "workshop", "book"]

    override func viewDidLoad() {
        super.viewDidLoad()
        dueDateChange.date = Date()
        imagePickerView.dataSource = self
        imagePickerView.delegate = self

        


        // Get a reference to the TasksTableViewController
        if let tableTableVC = self.tabBarController?.viewControllers?.compactMap({ $0 as? tableTableViewController }).first {
            self.tableTableViewController = tableTableVC
        }
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
                view.addGestureRecognizer(tapGesture)
    }
    
    
    // for add uiview picker u have taken refrence from the online source//
    // MARK: - UIPickerViewDataSource

        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1  // We want a single column
        }

        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            return imageNames.count
        }

        // MARK: - UIPickerViewDelegate

        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            return imageNames[row]  // Show image names in the picker
        }

        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            // Handle image selection here if needed
            let selectedImageName = imageNames[row]
            print("Selected image: \(selectedImageName)")
        }
    @objc func dismissKeyboard() {
            view.endEditing(true)
        }
    
    @IBOutlet weak var titleTextField: UITextField!
    
    
    @IBOutlet weak var descriptionTextField: UITextField!
    
    @IBOutlet weak var dueDateChange: UIDatePicker!
    

    @IBOutlet weak var imagePickerView: UIPickerView!
    
    @IBAction func resetButton(_ sender: UIButton) {
        titleTextField.text = ""
        descriptionTextField.text = ""
        dueDateChange.date = Date()
        
        // Reset date picker to current date/time
        imagePickerView.selectRow(0, inComponent: 0, animated: true)  // Reset UIPickerView to the first row
    }
    
    
  
    
    @IBAction func submitButton(_ sender: UIButton) {
        guard let title = titleTextField.text, !title.isEmpty else {
            showAlert(message: "Please enter a title.")
            return
        }
        
        guard let description = descriptionTextField.text, !description.isEmpty else {
            showAlert(message: "Please enter a description.")
            return
        }
        
        // Determine status based on due date
               let dueDate = dueDateChange.date
               let currentDate = Date()
               let status: String
               if dueDate < currentDate {
                   status = "Completed"
               } else {
                   status = "Pending"
               }
        
        let selectedRow = imagePickerView.selectedRow(inComponent: 0)
            let selectedImageName = imageNames[selectedRow]
               
               // Create a Task object
        let newTask = Task(title: title, description: description, dueDate: dueDate, status: status, imageName: selectedImageName)
               tasks.append(newTask)
               
               // Show success message
               showAlert(message: "Task created successfully.")
               
               // Clear form fields after successful submission
               titleTextField.text = ""
               descriptionTextField.text = ""
               dueDateChange.date = Date()
                imagePickerView.selectRow(0, inComponent: 0, animated: true)  // Reset UIPickerView to the first row
               
               // Pass the updated tasks array to tableTableViewController
               self.tableTableViewController?.tasks = self.tasks
        
        // Dismiss keyboard after submission
                titleTextField.resignFirstResponder()
                descriptionTextField.resignFirstResponder()
        
    }
    
            
            func showAlert(message: String) {
                let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                present(alertController, animated: true, completion: nil)
            }
    
}
    
   
    
    


