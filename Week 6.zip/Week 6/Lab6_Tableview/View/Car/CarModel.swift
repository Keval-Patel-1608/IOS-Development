//
//  CarModel.swift
//  Lab6_Tableview
//
//  Created by user244 on 2024-07-06.
//

import UIKit

struct Car {
    var image: UIImage?
    var make: String?
    var model: String?
}
