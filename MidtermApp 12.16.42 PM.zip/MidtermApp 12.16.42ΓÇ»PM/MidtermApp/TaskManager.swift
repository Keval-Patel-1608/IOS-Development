//
//  TaskManager.swift
//  MidtermApp
//
//  Created by user239680 on 7/3/24.
//
// This is a Singelton class 
import Foundation

class TaskManager {
    static let shared = TaskManager()
    
    private var tasks: [Task] = [] {
        didSet {
            saveTasks()
        }
    }
    
    private init() {
        loadTasks()
    }
    
    func addTask(_ task: Task) {
        tasks.append(task)
    }
    
    func getTasks() -> [Task] {
        return tasks
    }
    
    func removeTask(at index: Int) {
        tasks.remove(at: index)
        saveTasks()
    }
    
    func saveTasks() {
        if let encoded = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
            UserDefaults.standard.synchronize()
        }
    }
    
    private func loadTasks() {
        if let savedTasks = UserDefaults.standard.object(forKey: "tasks") as? Data {
            if let decodedTasks = try? JSONDecoder().decode([Task].self, from: savedTasks) {
                tasks = decodedTasks
            }
        }
    }
}

